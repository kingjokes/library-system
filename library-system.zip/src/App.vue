<template>
  <router-view />
</template>

<script setup>
  import '@/assets/css/w3.css'
</script>
